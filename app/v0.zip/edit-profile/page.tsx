import EditProfile from "@/components/edit-profile"

export default function EditProfilePage() {
  return <EditProfile />
}