import Component from "./joblist"

export default function Page() {
  return <Component />
}
