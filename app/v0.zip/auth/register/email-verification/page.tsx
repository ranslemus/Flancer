import EmailSent from "./email-sent"

export default function Page() {
  return <EmailSent />
}
